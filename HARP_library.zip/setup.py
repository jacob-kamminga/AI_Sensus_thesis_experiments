from setuptools import setup, find_packages


setup(
    name='harp',
    version='1.0.0',
    author='Maartje Huveneers, Rosalie Voorend, Suzanne Spink, Kevin Folkertsma, Wannes Vanwinsen',
    description="an accelerometry-based AAR pipeline",
    long_description=open('README.txt').read(),
    license='Apache Software License 2.0',
    packages=find_packages(),
)
